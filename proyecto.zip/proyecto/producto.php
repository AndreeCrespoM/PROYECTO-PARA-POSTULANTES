<?php session_start();
if (isset($_SESSION['usuario'])) {
	
}else{
	header('location: login.php');
}
require 'function.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$nombre_producto = filter_var(strtolower($_POST['nombre_producto']), FILTER_SANITIZE_STRING);
	$codigo = filter_var(strtolower($_POST['codigo']), FILTER_SANITIZE_STRING);
	$precio_venta = filter_var(strtolower($_POST['precio_venta']), FILTER_SANITIZE_STRING);
	$stock = filter_var(strtolower($_POST['stock']), FILTER_SANITIZE_STRING);

	
	$errores='';

	if (empty($nombre_producto) or empty($codigo) or empty($precio_venta) or empty($stock)) {
		$errores .= '<li>Por favor rellena los datos correctamente</li>';
	}else{
		$conexion=conexion($bd_config);
		$statement = $conexion->prepare('SELECT * FROM producto WHERE codigo = :codigo LIMIT 1');
		$statement->execute(array(':codigo' => $codigo));
		$resultado = $statement->fetch();

	
	if ($resultado != false) {
		$errores .= '<li>El producto ya esta registrado</li>';
	}	
	}
	if ($errores == '') {
		$statement = $conexion->prepare('INSERT INTO producto (id_producto, nombre_producto, codigo, precio_venta, stock) VALUES (null, :nombre_producto, :codigo, :precio_venta, :stock)');
		$statement->execute(array(':nombre_producto' => $nombre_producto, ':codigo' => $codigo, ':precio_venta' => $precio_venta, ':stock' => $stock));
		
	}
}

// Editar.
// if ($_SERVER['REQUEST_METHOD'] == 'POST') {
// 	$nombre_producto = filter_var(strtolower($_POST['nombre_producto']), FILTER_SANITIZE_STRING);
// 	$codigo = filter_var(strtolower($_POST['codigo']), FILTER_SANITIZE_STRING);
// 	$precio_venta = filter_var(strtolower($_POST['precio_venta']), FILTER_SANITIZE_STRING);
// 	$stock = filter_var(strtolower($_POST['stock']), FILTER_SANITIZE_STRING);

// 	$errores='';
// 	if (empty($nombre_producto) or empty($codigo) or empty($precio_venta) or empty($stock)) {
// 		$errores .= '<li>Por favor rellena los datos correctamente</li>';
// 	}else{
			
// 		$conexion=conexion($bd_config);
// 		$statement = $conexion->prepare('UPDATE producto SET nombre_producto = :nombre_producto, precio_venta = :precio_venta, stock = :stock WHERE codigo = :codigo');
// 		$statement->execute(array(':nombre_producto' => $nombre_producto, ':codigo' => $codigo, ':precio_venta' => $precio_venta, ':stock' => $stock));
// 	}
// }

//Borrar
// if ($_SERVER['REQUEST_METHOD'] == 'POST') {
// 	$codigo = filter_var(strtolower($_POST['codigo']), FILTER_SANITIZE_STRING);

// 	$errores='';
// 	if (empty($codigo)) {
// 		$errores .= '<li>Por favor rellena los datos correctamente</li>';
// 	}else{
// 		$conexion=conexion($bd_config);
// 		$statement = $conexion->prepare('SELECT * FROM producto WHERE codigo = :codigo LIMIT 1');
// 		$statement->execute(array(':codigo' => $codigo));
// 		$resultado = $statement->fetch();
		
// 		if ($resultado == false) {
// 		$errores .= '<li>El nombre del producto no existe</li>';
// 	}	
// 	}

// 	if ($errores == '') {
		
// 		$statement = $conexion->prepare('DELETE FROM producto WHERE codigo = :codigo');
// 		$statement->execute(array(':codigo' => $codigo));
		
// 	}
// }
require 'view/producto.view.php';
 ?>