<?php session_start();

if (isset($_SESSION['usuario'])) {
	header('location: menu.php');
}else{
	header('location: login.php');
}
require 'admin/config.php';
require 'function.php';

require 'login.php';

 ?>