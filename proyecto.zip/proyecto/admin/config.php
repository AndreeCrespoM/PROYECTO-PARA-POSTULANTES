<?php 

define('RUTA', 'C:\xampp\htdocs\cursoPHP\practicas\proyecto');

$bd_config = array(
	'basedatos'=>'proyecto',
	'usuario' => 'root',
	'pass' => ''
);

$blog_admin=array(
	'usuario'=>'Ian',
	'password'=>'123'
);

 ?>