<?php session_start();
require 'function.php';

if (isset($_SESSION['usuario'])) {
	header('location: index.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$usuario = filter_var(strtolower($_POST['usuario']), FILTER_SANITIZE_STRING);
	$password = $_POST['password'];

	
	$errores='';

	if (empty($usuario) or empty($password)) {
		$errores .= '<li>Por favor rellena los datos correctamente</li>';
	}else{
		$conexion=conexion($bd_config);
		$statement = $conexion->prepare('SELECT * FROM usuario WHERE usuario = :usuario LIMIT 1');
		$statement->execute(array(':usuario' => $usuario));
		$resultado = $statement->fetch();

	
	if ($resultado != false) {
		$errores .= '<li>El nombre de usuario ya existe</li>';
	}

	$password = hash('sha512', $password);
	
	}
	if ($errores == '') {
		$statement = $conexion->prepare('INSERT INTO usuario (id_usuario, usuario, pass) VALUES (null, :usuario, :pass)');
		$statement->execute(array(':usuario' => $usuario, ':pass' => $password));
		header('location: login.php');
	}
}

	

require 'view/registro.view.php';
 ?>