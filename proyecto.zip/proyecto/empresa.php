<?php session_start();
if (isset($_SESSION['usuario'])) {
	
}else{
	header('location: login.php');
}
require 'function.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$nombre_empresa = filter_var(strtolower($_POST['nombre_empresa']), FILTER_SANITIZE_STRING);
	$ruc = filter_var(strtolower($_POST['ruc']), FILTER_SANITIZE_STRING);
	$razon_social = filter_var(strtolower($_POST['razon_social']), FILTER_SANITIZE_STRING);

	
	$errores='';

	if (empty($nombre_empresa) or empty($ruc) or empty($razon_social)) {
		$errores .= '<li>Por favor rellena los datos correctamente</li>';
	}else{
		$conexion=conexion($bd_config);
		$statement = $conexion->prepare('SELECT * FROM empresa WHERE ruc = :ruc LIMIT 1');
		$statement->execute(array(':ruc' => $ruc));
		$resultado = $statement->fetch();

	
	if ($resultado != false) {
		$errores .= '<li>El nombre de usuario ya existe</li>';
	}	
	}
	if ($errores == '') {
		$statement = $conexion->prepare('INSERT INTO empresa (id_empresa, nombre_empresa, ruc, razon_social) VALUES (null, :nombre_empresa, :ruc, :razon_social)');
		$statement->execute(array(':nombre_empresa' => $nombre_empresa, ':ruc' => $ruc, ':razon_social' => $razon_social));
		
	}
}

// Editar.
// if ($_SERVER['REQUEST_METHOD'] == 'POST') {
// $nombre_empresa = filter_var(strtolower($_POST['nombre_empresa']), FILTER_SANITIZE_STRING);
// $ruc = filter_var(strtolower($_POST['ruc']), FILTER_SANITIZE_STRING);
// $razon_social = filter_var(strtolower($_POST['razon_social']), FILTER_SANITIZE_STRING);

// 	$errores='';
// 	if (empty($nombre_empresa) or empty($ruc) or empty($razon_social)) {
// 		$errores .= '<li>Por favor rellena los datos correctamente</li>';
// 	}else{
			
// 		$conexion=conexion($bd_config);
// 		$statement = $conexion->prepare('UPDATE empresa SET nombre_empresa = :nombre_empresa, razon_social = :razon_social WHERE ruc = :ruc');
// 		$statement->execute(array(':nombre_empresa' => $nombre_empresa, ':ruc' => $ruc, ':razon_social' => $razon_social));
// 	}
// }

//Borrar
// if ($_SERVER['REQUEST_METHOD'] == 'POST') {
// 	$ruc = filter_var(strtolower($_POST['ruc']), FILTER_SANITIZE_STRING);

// 	$errores='';
// 	if (empty($ruc)) {
// 		$errores .= '<li>Por favor rellena los datos correctamente</li>';
// 	}else{
// 		$conexion=conexion($bd_config);
// 		$statement = $conexion->prepare('SELECT * FROM empresa WHERE ruc = :ruc LIMIT 1');
// 		$statement->execute(array(':ruc' => $ruc));
// 		$resultado = $statement->fetch();
		
// 		if ($resultado == false) {
// 		$errores .= '<li>El nombre de la empresa no existe</li>';
// 	}	
// 	}

// 	if ($errores == '') {
		
// 		$statement = $conexion->prepare('DELETE FROM empresa WHERE ruc = :ruc');
// 		$statement->execute(array(':ruc' => $ruc));
		
// 	}
// }
require 'view/empresa.view.php';
 ?>