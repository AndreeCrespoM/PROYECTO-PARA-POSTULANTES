<?php 
$bd_config='';
function conexion($bd_config){
	try {
		$conexion = new PDO('mysql:host=127.0.0.1:3310;dbname=proyecto','root','');
		return $conexion;
	} catch (PDOException $e) {
		return false;
	}
}

//conexion($bd_config);<-Linea para realizar la conexion con la tabla.

function limpiarDatos($datos){
	$datos = trim($datos);
	$datos = stripcslashes($datos);
	$datos = htmlspecialchars($datos);
	return $datos;
}


?>