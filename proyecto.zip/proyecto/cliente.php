<?php session_start();
if (isset($_SESSION['usuario'])) {
	
}else{
	header('location: login.php');
}
require 'function.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$nombre_cliente = filter_var(strtolower($_POST['nombre_cliente']), FILTER_SANITIZE_STRING);
	$ci_ruc = filter_var(strtolower($_POST['ci_ruc']), FILTER_SANITIZE_STRING);
	$razon_social = filter_var(strtolower($_POST['razon_social']), FILTER_SANITIZE_STRING);

	
	$errores='';

	if (empty($nombre_cliente) or empty($ci_ruc) or empty($razon_social)) {
		$errores .= '<li>Por favor rellena los datos correctamente</li>';
	}else{
		$conexion=conexion($bd_config);
		$statement = $conexion->prepare('SELECT * FROM cliente WHERE ci_ruc = :ci_ruc LIMIT 1');
		$statement->execute(array(':ci_ruc' => $ci_ruc));
		$resultado = $statement->fetch();

	
	if ($resultado != false) {
		$errores .= '<li>El nombre de usuario ya existe</li>';
	}	
	}
	if ($errores == '') {
		$statement = $conexion->prepare('INSERT INTO cliente (id_cliente, nombre_cliente, ci_ruc, razon_social) VALUES (null, :nombre_cliente, :ci_ruc, :razon_social)');
		$statement->execute(array(':nombre_cliente' => $nombre_cliente, ':ci_ruc' => $ci_ruc, ':razon_social' => $razon_social));
		
	}
}

// Editar.
// if ($_SERVER['REQUEST_METHOD'] == 'POST') {
// 	$nombre_cliente = filter_var(strtolower($_POST['nombre_cliente']), FILTER_SANITIZE_STRING);
// 	$ci_ruc = filter_var(strtolower($_POST['ci_ruc']), FILTER_SANITIZE_STRING);
// 	$razon_social = filter_var(strtolower($_POST['razon_social']), FILTER_SANITIZE_STRING);

// 	$errores='';
// 	if (empty($nombre_cliente) or empty($ci_ruc) or empty($razon_social)) {
// 		$errores .= '<li>Por favor rellena los datos correctamente</li>';
// 	}else{
			
// 		$conexion=conexion($bd_config);
// 		$statement = $conexion->prepare('UPDATE cliente SET nombre_cliente = :nombre_cliente, razon_social = :razon_social WHERE ci_ruc = :ci_ruc');
// 		$statement->execute(array(':nombre_cliente' => $nombre_cliente, ':ci_ruc' => $ci_ruc, ':razon_social' => $razon_social));
// 	}
// }

//Borrar
// if ($_SERVER['REQUEST_METHOD'] == 'POST') {
// 	$ci_ruc = filter_var(strtolower($_POST['ci_ruc']), FILTER_SANITIZE_STRING);

// 	$errores='';
// 	if (empty($ci_ruc)) {
// 		$errores .= '<li>Por favor rellena los datos correctamente</li>';
// 	}else{
// 		$conexion=conexion($bd_config);
// 		$statement = $conexion->prepare('SELECT * FROM cliente WHERE ci_ruc = :ci_ruc LIMIT 1');
// 		$statement->execute(array(':ci_ruc' => $ci_ruc));
// 		$resultado = $statement->fetch();
		
// 		if ($resultado == false) {
// 		$errores .= '<li>El nombre de usuario no existe</li>';
// 	}	
// 	}

// 	if ($errores == '') {
		
// 		$statement = $conexion->prepare('DELETE FROM cliente WHERE ci_ruc = :ci_ruc');
// 		$statement->execute(array(':ci_ruc' => $ci_ruc));
		
// 	}
// }
require 'view/cliente.view.php';
 ?>