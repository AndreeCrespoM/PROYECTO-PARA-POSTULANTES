<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Empresas</title>
</head>
<body>
			
	<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="POST" name="empresa">
		<div>
			<button type="button">Buscar</button>
			<input type="text" name="ruc" placeholder="RUC">
		</div>
		<div>
			<button type="button" onclick="empresa.submit()">Ingresar</button>
			<input type="text" name="nombre_empresa" placeholder="Institucion">
		</div>

		<div>
			<button type="button">Editar</button>
			<input type="text" name="razon_social" placeholder="Razon Social">
		</div>
			<button type="button">Borrar</button>
		<a href="menu.php">regresar</a>
		
	</form>
	<?php if(!empty($errores)): ?>
			<div>
				<ul>
					<?php echo $errores; ?>
				</ul>
			</div>
		<?php endif; ?>	
</body>
</html>