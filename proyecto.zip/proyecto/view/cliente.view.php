<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Clientes</title>
</head>
<body>
	
	<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="POST" name="cliente">
		<div>
			<button type="button">Buscar</button>
			<input type="text" name="ci_ruc" placeholder="CI_RUC">
		</div>
		<div>
			<button type="button" onclick="cliente.submit()">Ingresar</button>
			<input type="text" name="nombre_cliente" placeholder="Nombre">
		</div>

		<div>
			<button type="button">Editar</button>
			<input type="text" name="razon_social" placeholder="Razon Social">
		</div>
			<button type="button">Borrar</button>
		<a href="menu.php">regresar</a>
		
	</form>
	<?php if(!empty($errores)): ?>
			<div>
				<ul>
					<?php echo $errores; ?>
				</ul>
			</div>
		<?php endif; ?>
</body>
</html>