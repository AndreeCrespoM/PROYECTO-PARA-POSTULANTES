<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Iniciar Sesion</title>
</head>
<body>
	<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="POST" name="login">
		
		<div>
			<label>Usuario:</label>
			<input type="text" name="usuario">
		</div>
		<div>
			<label>Contraseña:</label>
			<input type="password" name="password">
		</div>
		<button type="button" onclick="login.submit()">Entrar</button>
		<a href="registro.php">Registrar usuario</a>
		<?php if(!empty($errores)): ?>
			<div>
				<ul>
					<?php echo $errores; ?>
				</ul>
			</div>
		<?php endif; ?>		
	</form>
</body>
</html>