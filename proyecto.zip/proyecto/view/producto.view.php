<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Producto</title>
</head>
<body>
	
	<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="POST" name="producto">
		<div>
			<button type="button">Buscar</button>
			<input type="text" name="codigo" placeholder="Codigo">
		</div>
		<div>
			<button type="button" onclick="producto.submit()">Ingresar</button>
			<input type="text" name="nombre_producto" placeholder="Nombre">
		</div>

		<div>
			<button type="button">Editar</button>
			<input type="text" name="precio_venta" placeholder="Precio">
		</div>
		<div>
			<button type="button">Borrar</button>
			<input type="text" name="stock" placeholder="Stock">
		</div>
			
		<a href="menu.php">regresar</a>
		
	</form>
	<?php if(!empty($errores)): ?>
			<div>
				<ul>
					<?php echo $errores; ?>
				</ul>
			</div>
		<?php endif; ?>
</body>
</html>