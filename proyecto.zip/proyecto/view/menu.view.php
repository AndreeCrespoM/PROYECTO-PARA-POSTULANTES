<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Menu</title>
</head>
<body>		
	<form action="cliente.php" name="btnclientes">
		<button type="button"  onclick="btnclientes.submit()">Clientes</button>
	</form>
	<form action="empresa.php" name="btnempresas">
		<button type="button"  onclick="btnempresas.submit()">Empresas</button>
	</form>
	<form action="producto.php" name="btnproducto">
		<button type="button"  onclick="btnproducto.submit()">Productos</button>
	</form>
	<a href="cerrar.php">cerrar sesion</a>
</body>
</html>