<?php session_start();
if (isset($_SESSION['usuario'])) {
	require 'view/menu.view.php';
}else{
	header('location: login.php');
}

 ?>